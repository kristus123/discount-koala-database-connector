import setuptools

setuptools.setup(
    name="discountKoala",
    version="0.0.1",
    author="todo",
    author_email="todo",
    description="todo",
    packages=setuptools.find_packages(),
    python_requires='>=3.7',
)